import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

def detect_anomalies(file_name, n_clusters=3):
    data = pd.read_csv(file_name)

     # Print column names to inspect
    print("Columns in the dataset:", data.columns)
    
    # Rename columns if necessary (e.g., numerical column names)
    if '50.33' in data.columns and '27.53' in data.columns:
        data.rename(columns={'50.33': 'Temp_Value', '27.53': 'Precipitation'}, inplace=True)
    
    
    # Use temperature and precipitation for clustering
    features = data[['Temp_Value', 'Precipitation']].dropna()  # Remove missing data if present
    
    # Standardize the features
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)
    
    # Perform K-Means clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=0).fit(scaled_features)
    
    # Add the cluster labels to the original data
    data.loc[features.index, 'Cluster'] = kmeans.labels_  # Ensure only rows without NaNs get labels
    
    # Save the data with cluster labels
    data.to_csv('/Users/vishesh/Desktop/geo_project/anomaly_detected_data.csv', index=False)
    print(f"Anomaly detection complete. Data saved as anomaly_detected_data.csv with {n_clusters} clusters.")

if __name__ == "__main__":
    detect_anomalies('/Users/vishesh/Desktop/geo_project/preprocessed_climate_data.csv', n_clusters=3)


