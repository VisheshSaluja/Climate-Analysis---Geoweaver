import os
import requests

# NOAA Temperature Data
temp_url = 'https://www.ncdc.noaa.gov/cag/national/time-series/110-tavg-all-12-1880-2023.csv'
# World Bank Precipitation Data (Example URL)
precip_url = 'https://data.worldbank.org/indicator/AG.LND.PRCP.MM'

# Function to download data
def download_data():
    temp_file = "temperature_data.csv"
    precip_file = "precipitation_data.csv"
    
    # Download temperature data
    temp_response = requests.get(temp_url)
    with open(temp_file, 'wb') as file:
        file.write(temp_response.content)
    
    # Download precipitation data
    precip_response = requests.get(precip_url)
    with open(precip_file, 'wb') as file:
        file.write(precip_response.content)
    
    print(f"Data downloaded: {temp_file}, {precip_file}")

if __name__ == "__main__":
    download_data()

