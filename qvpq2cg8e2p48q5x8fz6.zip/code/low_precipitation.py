import pandas as pd

def load_precipitation_data(file_path):
    """
    Loads the precipitation dataset from a CSV file.
    
    :param file_path: Path to the CSV file containing precipitation data
    :return: Pandas DataFrame
    """
    df = pd.read_csv(file_path, error_bad_lines=False, warn_bad_lines=True)
    df.columns = ['Date', 'Precipitation']  # Rename columns
    df['Date'] = pd.to_datetime(df['Date'], format='%Y%m')  # Convert 'Date' to datetime
    df = df[df['Precipitation'] != -99]  # Filter out missing data (-99)
    return df

if __name__ == "__main__":
    precipitation_df = load_precipitation_data('/Users/vishesh/Desktop/geo_project/data-2.csv')
    if precipitation_df is not None:
        print(precipitation_df.head())
    else:
        print("Failed to load the data.")

