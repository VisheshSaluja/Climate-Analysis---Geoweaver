import pandas as pd

def analyze_trends(file_name):
    # Load the data
    data = pd.read_csv(file_name)
    
    # Rename columns to more meaningful names
    data.columns = ['Year', 'Temp_Value', 'Precipitation']
    
    # Calculate 10-year moving averages for both temperature and precipitation
    data['10-year temp avg'] = data['Temp_Value'].rolling(window=10).mean()
    data['10-year precip avg'] = data['Precipitation'].rolling(window=10).mean()
    
    # Save the analyzed data
    data.to_csv('/Users/vishesh/Desktop/geo_project/analyzed_climate_data.csv', index=False)
    print("Analyzed trends saved as analyzed_climate_data.csv")

if __name__ == "__main__":
    analyze_trends('/Users/vishesh/Desktop/geo_project/preprocessed_climate_data.csv')

